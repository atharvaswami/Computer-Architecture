import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {

    public static double average(int[] infiltrationTime) {
        assert infiltrationTime.length > 0 : "The list should not be empty";
        int sum = 0;

        for (double currentTime : infiltrationTime)
            sum += currentTime;

        return sum / infiltrationTime.length;
    }

    public static double simulate(int borderLength, int borderWidth, double headsProbability) {

        int iterations = 50;
        int[] infiltrationTime = new int[iterations];

        for (int i = 0; i < iterations; i += 1) {
            Infiltrator soldier = new Infiltrator(borderLength, borderWidth, headsProbability);
            Clock watch = new Clock(10);

            while (!soldier.hasReachedDC()) {
                soldier.nextMove();
                watch.changeTime();
            }

            infiltrationTime[i] = watch.changeTime();
        }

        return average(infiltrationTime);
    }

    public static void main(String[] args) {
        String inputFile = args[0];
        String outputFile = args[1];

        System.out.println("\nCommand Line Args: " + inputFile + " " + outputFile);
        Scanner input;
        try {
            input = new Scanner(new File(inputFile));

            PrintWriter writer = new PrintWriter(outputFile);

            ArrayList<Double> probabilities = Stream.of(input.nextLine().split(" ")).map(i -> Double.valueOf(i)).collect(Collectors.toCollection(ArrayList:: new));
            ArrayList<Integer> widths = Stream.of(input.nextLine().split(" ")).map(i -> Integer.valueOf(i)).collect(Collectors.toCollection(ArrayList:: new));

            double[] infiltrationTime = new double[widths.size()*probabilities.size()];
            int borderLength = 1000;

            for (int i = 0, k = 0; i < probabilities.size(); i += 1) {
                for (int j = 0; j < widths.size(); j += 1) {
                    infiltrationTime[k] = simulate(borderLength, widths.get(j), probabilities.get(i));

                    String data = String.valueOf(probabilities.get(i)) + ", " + String.valueOf(widths.get(j)) + ", " + String.valueOf(infiltrationTime[k]);

                    writer.println(data);
                    k += 1;
                }
            }

            writer.close();

            System.out.println(Arrays.toString(infiltrationTime));

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

}