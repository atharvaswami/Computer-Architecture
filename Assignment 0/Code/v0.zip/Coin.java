import java.lang.Math;

public class Coin {

    public double headsProbability;

    Coin(final double headsProbability) {
        assert headsProbability > 0 && headsProbability < 1: "Probability should be between 0 & 1";
        this.headsProbability = headsProbability;
    }

    public boolean toss() {
        return (boolean)(Math.random() < this.headsProbability);
    }
    
}
