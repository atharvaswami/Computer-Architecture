public class Clock {
    private int currentTime;
    private final int duration;

    Clock(final int duration) {
        this.duration = duration;
        this.currentTime = 0;
    }

    public int changeTime() {
        this.currentTime += this.duration;
        return this.currentTime;
    }
}
