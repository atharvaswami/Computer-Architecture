public class Border {
    private int length;
    private int width;
    private double headsProbability;
    private Sensor[][] cells;

    Border(int borderLength, int borderWidth, double headsProbability) {
        this.length = borderLength;
        this.width = borderWidth;
        this.headsProbability = headsProbability;
        this.cells = new Sensor[this.width][this.length];

        for (int i = 0; i < this.width; i += 1) {
            for (int j = 0; j < this.length; j += 1)
                this.cells[i][j] = new Sensor(this.headsProbability);
        }
    }

    public String toString() {
        String cellsStatus = new String();

        for (int i = 0; i < this.width; i += 1) {
            for (int j = 0; j < this.length; j += 1)
                cellsStatus += this.cells[i][j].toString() + " ";
            cellsStatus += '\n';
        }

        return cellsStatus;
    }

    public boolean isDC(int x, int y) {
        return x >= this.width;
    }

    public boolean isActive(int x, int y) {
        if (x < 0 || y < 0)
            return true;
        else if (y >= this.length || x >= this.width)
            return false;

        return cells[x][y].checkStatus();
    }

    public void restartCells() {
        for (int i = 0; i < this.width; i += 1) {
            for (int j = 0; j < this.length; j += 1)
                this.cells[i][j].restart();
        }
    }

}
