public class Infiltrator {
    private boolean reachedDC;
    private Border border;
    private int currX;
    private int currY;

    Infiltrator(int borderLength, int borderWidth, double headsProbability) {
        this.reachedDC = false;
        this.border = new Border(borderLength, borderWidth, headsProbability);
        this.currX = 0;
        this.currY = 0;
    }

    public boolean hasReachedDC() {
        return this.reachedDC;
    }

    public void nextMove() {
        if (this.hasReachedDC())
            return;

        this.border.restartCells();

        boolean nearbyCells[][] = new boolean[3][3];
        for (int i = -1; i < 2; i += 1) {
            for (int j = -1; j < 2; j += 1) {
                nearbyCells[i+1][j+1] = this.border.isActive(currX + i, currY + j);
            }
        }

        for (int j = 1, i = 1; j >= -1; j -= 1) {
            if (nearbyCells[i+1][j+1] == false) {
                this.currX += i;
                this.currY += j;
                break;
            }
        }

        this.reachedDC |= this.border.isDC(currX, currY);
    }

    public String getCoordinates() {
        return String.valueOf(this.currX) + "," + String.valueOf(this.currY);
    }

    public String toString() {
        return "Infiltrator's position: (" + this.getCoordinates() + ")";
    }
}
