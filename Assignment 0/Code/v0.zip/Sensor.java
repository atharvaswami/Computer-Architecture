public class Sensor {
    private boolean isActive;
    private Coin coin;

    Sensor(final double headsProbability) {
        this.coin = new Coin(headsProbability);
        this.isActive = false;
    }

    public String toString() {
        return String.valueOf(this.isActive);
    }

    public boolean checkStatus() {
        return this.isActive;
    }

    public void restart() {
        this.isActive = this.coin.toss();
    }
}
