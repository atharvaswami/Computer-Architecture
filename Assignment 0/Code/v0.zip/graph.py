from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt

probabilities, widths, duration = [], [], []

with open('output.txt') as reader:
	outputFile = reader.read()
	outputFile = outputFile.replace(' ', '').replace('\n', ',').split(',')

	i = 0
	while i < len(outputFile) - 3:
		probabilities.append(float(outputFile[i]))
		widths.append(int(outputFile[i+1]))
		duration.append(float(outputFile[i+2]))
		i += 3

fig = plt.figure()
graph = fig.add_subplot(111, projection='3d', xlabel='Probability', ylabel='Width', zlabel='Time (s)')
graph.plot(xs=probabilities, ys=widths, zs=duration)

plt.savefig('graph.png')