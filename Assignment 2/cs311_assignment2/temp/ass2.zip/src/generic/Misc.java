package generic;

public class Misc {
	
	public static void printErrorAndExit(String message)
	{
		System.err.println(message);
		System.exit(1);
	}
}
